export const createActions = (type, payload) => ({ type, payload });
